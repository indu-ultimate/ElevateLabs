# ElevateLabs
Task3

The following insights were derived using sql

# Show total number of customers from each country.



# Find the number of unique customers from each country.



# List product_name and total quantity sold for each product.



# Find the average rating of each product category.



# Overall Average Order Value



# Get the top 5 products (product_id, product_name) with the highest total sales revenue (quantity * unit_price).

# Find the total number of orders placed each year.


# Find customers who have placed more than 6 orders.

# Retrieve the top 5 customers who spent the most overall (include total_spent column).


# Find the percentage of completed vs cancelled orders for each payment_method.


# Identify customers who gave a rating ≤ 3 but still placed more than 3 orders afterward.



# Using a window function, rank products by total revenue within each category.



# Using a window function, rank find top sold product within each category.


# Find the customer churn rate: percentage of customers who signed up in 2022 but didn’t place any order in 2023.



# Top products by average rating in each category (only products with ≥ 5 reviews)


# Customer lifetime value (CLV) by country

# Calculate the percentage of repeat customers vs one-time customers


