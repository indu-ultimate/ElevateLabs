use sandbox;
# Show total number of customers from each country.

select country,count(customer_id) as No_of_Customers from ecommerce_dataset_10000
group by country 
order by No_of_Customers;

# Find the number of unique customers from each country.

select country,count(distinct customer_id) as unique_customers from ecommerce_dataset_10000
group by country 
order by unique_customers;

# List product_name and total quantity sold for each product.

select product_name,sum(quantity) as total_quantity from ecommerce_dataset_10000
group by product_name
order by total_quantity desc;

# Find the average rating of each product category.

select category,round(avg(rating),2) as average_rating from ecommerce_dataset_10000
group by category
order by average_rating desc;

# Overall Average Order Value

select round(sum(quantity*unit_price*1.0)/count(customer_id),2) as overall_average_order_value from ecommerce_dataset_10000;

# Get the top 5 products (product_id, product_name) with the highest total sales revenue (quantity * unit_price).

select product_id,product_name, sum(quantity * unit_price) as total_revenue from ecommerce_dataset_10000
group by product_id,product_name
order by total_revenue desc
limit 5;

# Find the total number of orders placed each year.
select year(order_date) as each_year,count(order_id) as total_orders from ecommerce_dataset_10000
group by each_year
order by each_year;

# Find customers who have placed more than 6 orders.
select customer_id,first_name,last_name,count(order_id) as total_orders from ecommerce_dataset_10000
group by customer_id,first_name,last_name
having total_orders >6
order by total_orders;

# Retrieve the top 5 customers who spent the most overall (include total_spent column).
select customer_id,first_name,last_name,round(sum(quantity*unit_price), 2) as total_spent from ecommerce_dataset_10000
group by customer_id,first_name,last_name
order by total_spent desc
limit 5;

# Find the percentage of completed vs cancelled orders for each payment_method.
select payment_method,
Round((sum(CASE WHEN order_status = 'Completed' THEN 1 ELSE 0 END)/count(*))*100.0, 2) as pym_completed,
Round((sum(CASE WHEN order_status = 'Cancelled' THEN 1 ELSE 0 END)/count(*))*100.0, 2) as pym_cancelled
from ecommerce_dataset_10000
group by payment_method
order by pym_completed;

# Identify customers who gave a rating ≤ 3 but still placed more than 3 orders afterward.

WITH low_rated_orders AS(
select customer_id,
min(order_date) as first_order_rated_low
from ecommerce_dataset_10000
where rating <=3
group by customer_id
),
orders_placed_after_lowrating AS(
select e1.customer_id,
count(distinct e1.order_id) as orders_placed_after_lowrating
from ecommerce_dataset_10000 as e1
join low_rated_orders lro on e1.customer_id = lro.customer_id
where e1.order_date > lro.first_order_rated_low
group by e1.customer_id
)
select op.customer_id,e2.first_name,e2.last_name,op.orders_placed_after_lowrating
from orders_placed_after_lowrating as op
join ecommerce_dataset_10000 e2 on 
e2.customer_id = op.customer_id
group by op.customer_id
having orders_placed_after_lowrating > 3

order by orders_placed_after_lowrating  desc;

#######
WITH low_rated_orders AS (
    SELECT 
        customer_id, 
        MIN(order_date) AS first_low_rating_date
    FROM orders
    WHERE rating <= 3
    GROUP BY customer_id
),
orders_after_low_rating AS (
    SELECT 
        o.customer_id,
        COUNT(DISTINCT o.order_id) AS orders_after_low_rating
    FROM ecommerce_dataset_10000 o
    JOIN low_rated_orders lro
      ON o.customer_id = lro.customer_id
    WHERE o.order_date > lro.first_low_rating_date
    GROUP BY o.customer_id
)
SELECT 
    o.customer_id,
    c.first_name,
    c.last_name,
    o.orders_after_low_rating
FROM orders_after_low_rating o
JOIN ecommerce_dataset_10000 c
  ON o.customer_id = c.customer_id
GROUP BY o.customer_id
HAVING orders_after_low_rating > 3
ORDER BY orders_after_low_rating DESC;

# Using a window function, rank products by total revenue within each category.

select product_id,product_name,category,
sum(quantity*unit_price) as total_revenue,
rank() over (partition by category order by sum(quantity*unit_price) desc) as r
from ecommerce_dataset_10000
group by product_id,product_name,category
order by category,r;

# Using a window function, rank find top sold product within each category.

select * from
(select product_id,product_name,category,
sum(quantity) as top_sold,
rank() over (partition by category order by sum(quantity) desc) as rnk
from ecommerce_dataset_10000
group by product_id,product_name,category
order by category,rnk) as t
where t.rnk=1;

# Find the customer churn rate: percentage of customers who signed up in 2022 but didn’t place any order in 2023.

WITH customers_2022 AS(
select customer_id
from ecommerce_dataset_10000
where date_format(signup_date,'%Y') = '2022'
),

customers_churn_2023 AS(
select distinct customer_id
from ecommerce_dataset_10000
where date_format(order_date,'%Y')='2023'
)

select 
Round((count(c2.customer_id) - count(c3.customer_id))/count(c2.customer_id) *100.0,2) as churn_percent
from customers_2022 c2
left join customers_churn_2023 c3 on 
c2.customer_id=c3.customer_id;

# Top products by average rating in each category (only products with ≥ 5 reviews)

select * from 
(select product_id,product_name,category,avg(rating) as avg_rating,COUNT(rating) as review_counts,
rank() over (partition by category order by avg(rating)) as rnk
from ecommerce_dataset_10000
group by product_id,product_name,category
order by category,avg_rating 
) as t
having review_counts >=5;

WITH product_avg_rating AS(
select product_id,product_name,category,avg(rating) as avg_rating,COUNT(rating) as review_counts
from ecommerce_dataset_10000
group by product_id,product_name,category
having review_counts >=5
)
select product_id,product_name,category,avg_rating,
rank() OVER (partition by category order by avg_rating desc) as rnk
from product_avg_rating
order by category,avg_rating;

# Customer lifetime value (CLV) by country
WITH customer_spending AS(
select customer_id,country,sum(quantity*unit_price) as total_spent
from ecommerce_dataset_10000
group by customer_id,country
)
select country,round(avg(total_spent),2) as avg_clv
from customer_spending
group by country
order by avg_clv desc;

# Calculate the percentage of repeat customers vs one-time customers



WITH customer_order_counts AS (
    SELECT 
        customer_id,
        COUNT(DISTINCT order_id) AS total_orders
    FROM ecommerce_dataset_10000
    GROUP BY customer_id
)
SELECT
    SUM(CASE WHEN total_orders = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS pct_one_time,
    SUM(CASE WHEN total_orders > 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS pct_repeat
FROM customer_order_counts;